
<?php $this->load->view('/templates/header'); ?>
<h1   style="text-align:center;"> About </h1>
<?php $this->load->view('/templates/footer'); ?>

