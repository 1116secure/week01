


<?php $this->load->view('/templates/header'); ?>
<h1   style="text-align:center;"> Home </h1>
<?php 
//echo $msg ; 
?>
 
<?php $this->load->view('/templates/footer'); ?>

